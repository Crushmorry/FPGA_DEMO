//-----------------------------------------------------------------------------
//   ____  ____
//  /   /\/   /
// /___/  \  /   Vendor: Xilinx
// \   \   \/    Version: 2.0
//  \   \        Filename: $RCSfile: run_bitacc_cmodel.c,v $
//  /   /        Date Last Modified: $Date: 2011-03-03 09:28:06 -0700 (Thu, 03 Mar 2011) $
// /___/   /\    Date Created: 2009
// \   \  /  \
//  \___\/\___\
//
// Device  : All
// Library : v_osd_v6_0
// Purpose : Smoke test program for bit accurate C model
//-----------------------------------------------------------------------------
//  (c) Copyright 2011 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES. 
//-----------------------------------------------------------------------------
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
//#include <iostream.h>

#include "rgb_utils.h"
#include "yuv_utils.h"
#include "video_utils.h"
#include "v_osd_v6_0_bitacc_cmodel.h"

#ifdef NT
#pragma comment(lib, "libIp_v_osd_v6_0_bitacc_cmodel.lib");
#endif
//using namespace std;

const int osd_charmap[] = 
{
0x00, 0x36, 0x7F, 0x7F, 0x3E, 0x1C, 0x08, 0x00, // NULL
0x18, 0x18, 0x18, 0x1F, 0x1F, 0x18, 0x18, 0x18,
0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,
0x18, 0x18, 0x18, 0xF8, 0xF8, 0x00, 0x00, 0x00,
0x18, 0x18, 0x18, 0xF8, 0xF8, 0x18, 0x18, 0x18,
0x00, 0x00, 0x00, 0xF8, 0xF8, 0x18, 0x18, 0x18,
0x03, 0x07, 0x0E, 0x1C, 0x38, 0x70, 0xE0, 0xC0,
0xC0, 0xE0, 0x70, 0x38, 0x1C, 0x0E, 0x07, 0x03,
0x01, 0x03, 0x07, 0x0F, 0x1F, 0x3F, 0x7F, 0xFF,
0x00, 0x00, 0x00, 0x00, 0x0F, 0x0F, 0x0F, 0x0F,
0x80, 0xC0, 0xE0, 0xF0, 0xF8, 0xFC, 0xFE, 0xFF,
0x0F, 0x0F, 0x0F, 0x0F, 0x00, 0x00, 0x00, 0x00,
0xF0, 0xF0, 0xF0, 0xF0, 0x00, 0x00, 0x00, 0x00,
0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF,
0x00, 0x00, 0x00, 0x00, 0xF0, 0xF0, 0xF0, 0xF0,
0x00, 0x1C, 0x1C, 0x77, 0x77, 0x08, 0x1C, 0x00,
0x00, 0x00, 0x00, 0x1F, 0x1F, 0x18, 0x18, 0x18,
0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0x00,
0x18, 0x18, 0x18, 0xFF, 0xFF, 0x18, 0x18, 0x18,
0x00, 0x00, 0x3C, 0x7E, 0x7E, 0x7E, 0x3C, 0x00,
0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF,
0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0, 0xC0,
0x00, 0x00, 0x00, 0xFF, 0xFF, 0x18, 0x18, 0x18,
0x18, 0x18, 0x18, 0xFF, 0xFF, 0x00, 0x00, 0x00,
0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
0x18, 0x18, 0x18, 0x1F, 0x1F, 0x00, 0x00, 0x00,
0x78, 0x60, 0x78, 0x60, 0x7E, 0x18, 0x1E, 0x00,
0x00, 0x18, 0x3C, 0x7E, 0x18, 0x18, 0x18, 0x00,
0x00, 0x18, 0x18, 0x18, 0x7E, 0x3C, 0x18, 0x00,
0x00, 0x18, 0x30, 0x7E, 0x30, 0x18, 0x00, 0x00,
0x00, 0x18, 0x0C, 0x7E, 0x0C, 0x18, 0x00, 0x00,


0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // Space
0x00, 0x18, 0x18, 0x18, 0x18, 0x00, 0x18, 0x00,
0x00, 0x66, 0x66, 0x66, 0x00, 0x00, 0x00, 0x00,
0x00, 0x66, 0xFF, 0x66, 0x66, 0xFF, 0x66, 0x00,
0x18, 0x3E, 0x60, 0x3C, 0x06, 0x7C, 0x18, 0x00,
0x00, 0x66, 0x6C, 0x18, 0x30, 0x66, 0x46, 0x00,
0x1C, 0x36, 0x1C, 0x38, 0x6F, 0x66, 0x3B, 0x00,
0x00, 0x18, 0x18, 0x18, 0x00, 0x00, 0x00, 0x00,
0x00, 0x0E, 0x1C, 0x18, 0x18, 0x1C, 0x0E, 0x00,
0x00, 0x70, 0x38, 0x18, 0x18, 0x38, 0x70, 0x00,
0x00, 0x66, 0x3C, 0xFF, 0x3C, 0x66, 0x00, 0x00,
0x00, 0x18, 0x18, 0x7E, 0x18, 0x18, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x18, 0x30,
0x00, 0x00, 0x00, 0x7E, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x18, 0x00,
0x00, 0x06, 0x0C, 0x18, 0x30, 0x60, 0x40, 0x00,
0x00, 0x3C, 0x66, 0x6E, 0x76, 0x66, 0x3C, 0x00,
0x00, 0x18, 0x38, 0x18, 0x18, 0x18, 0x7E, 0x00,
0x00, 0x3C, 0x66, 0x0C, 0x18, 0x30, 0x7E, 0x00,
0x00, 0x7E, 0x0C, 0x18, 0x0C, 0x66, 0x3C, 0x00,
0x00, 0x0C, 0x1C, 0x3C, 0x6C, 0x7E, 0x0C, 0x00,
0x00, 0x7E, 0x60, 0x7C, 0x06, 0x66, 0x3C, 0x00,
0x00, 0x3C, 0x60, 0x7C, 0x66, 0x66, 0x3C, 0x00,
0x00, 0x7E, 0x06, 0x0C, 0x18, 0x30, 0x30, 0x00,
0x00, 0x3C, 0x66, 0x3C, 0x66, 0x66, 0x3C, 0x00,
0x00, 0x3C, 0x66, 0x3E, 0x06, 0x0C, 0x38, 0x00,
0x00, 0x00, 0x18, 0x18, 0x00, 0x18, 0x18, 0x00,
0x00, 0x00, 0x18, 0x18, 0x00, 0x18, 0x18, 0x30,
0x06, 0x0C, 0x18, 0x30, 0x18, 0x0C, 0x06, 0x00,
0x00, 0x00, 0x7E, 0x00, 0x00, 0x7E, 0x00, 0x00,
0x60, 0x30, 0x18, 0x0C, 0x18, 0x30, 0x60, 0x00,
0x00, 0x3C, 0x66, 0x0C, 0x18, 0x00, 0x18, 0x00,



0x00, 0x3C, 0x66, 0x6E, 0x6E, 0x60, 0x3E, 0x00, // @
0x00, 0x18, 0x3C, 0x66, 0x66, 0x7E, 0x66, 0x00, // A
0x00, 0x7C, 0x66, 0x7C, 0x66, 0x66, 0x7C, 0x00,
0x00, 0x3C, 0x66, 0x60, 0x60, 0x66, 0x3C, 0x00,
0x00, 0x78, 0x6C, 0x66, 0x66, 0x6C, 0x78, 0x00,
0x00, 0x7E, 0x60, 0x7C, 0x60, 0x60, 0x7E, 0x00,
0x00, 0x7E, 0x60, 0x7C, 0x60, 0x60, 0x60, 0x00,
0x00, 0x3E, 0x60, 0x60, 0x6E, 0x66, 0x3E, 0x00,
0x00, 0x66, 0x66, 0x7E, 0x66, 0x66, 0x66, 0x00,
0x00, 0x7E, 0x18, 0x18, 0x18, 0x18, 0x7E, 0x00,
0x00, 0x06, 0x06, 0x06, 0x06, 0x66, 0x3C, 0x00,
0x00, 0x66, 0x6C, 0x78, 0x78, 0x6C, 0x66, 0x00,
0x00, 0x60, 0x60, 0x60, 0x60, 0x60, 0x7E, 0x00,
0x00, 0x63, 0x77, 0x7F, 0x6B, 0x63, 0x63, 0x00,
0x00, 0x66, 0x76, 0x7E, 0x7E, 0x6E, 0x66, 0x00,
0x00, 0x3C, 0x66, 0x66, 0x66, 0x66, 0x3C, 0x00,
0x00, 0x7C, 0x66, 0x66, 0x7C, 0x60, 0x60, 0x00,
0x00, 0x3C, 0x66, 0x66, 0x66, 0x6C, 0x36, 0x00,
0x00, 0x7C, 0x66, 0x66, 0x7C, 0x6C, 0x66, 0x00,
0x00, 0x3C, 0x60, 0x3C, 0x06, 0x06, 0x3C, 0x00,
0x00, 0x7E, 0x18, 0x18, 0x18, 0x18, 0x18, 0x00,
0x00, 0x66, 0x66, 0x66, 0x66, 0x66, 0x7E, 0x00,
0x00, 0x66, 0x66, 0x66, 0x66, 0x3C, 0x18, 0x00,
0x00, 0x63, 0x63, 0x6B, 0x7F, 0x77, 0x63, 0x00,
0x00, 0x66, 0x66, 0x3C, 0x3C, 0x66, 0x66, 0x00,
0x00, 0x66, 0x66, 0x3C, 0x18, 0x18, 0x18, 0x00,
0x00, 0x7E, 0x0C, 0x18, 0x30, 0x60, 0x7E, 0x00,
0x00, 0x1E, 0x18, 0x18, 0x18, 0x18, 0x1E, 0x00,
0x00, 0x40, 0x60, 0x30, 0x18, 0x0C, 0x06, 0x00,
0x00, 0x78, 0x18, 0x18, 0x18, 0x18, 0x78, 0x00,
0x00, 0x08, 0x1C, 0x36, 0x63, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0x00,


0x40, 0x40, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, // `
0x00, 0x00, 0x3C, 0x06, 0x3E, 0x66, 0x3E, 0x00, // a
0x00, 0x60, 0x60, 0x7C, 0x66, 0x66, 0x7C, 0x00,
0x00, 0x00, 0x3C, 0x60, 0x60, 0x60, 0x3C, 0x00,
0x00, 0x06, 0x06, 0x3E, 0x66, 0x66, 0x3E, 0x00,
0x00, 0x00, 0x3C, 0x66, 0x7E, 0x60, 0x3C, 0x00,
0x00, 0x0E, 0x18, 0x3E, 0x18, 0x18, 0x18, 0x00,
0x00, 0x00, 0x3E, 0x66, 0x66, 0x3E, 0x06, 0x7C,
0x00, 0x60, 0x60, 0x7C, 0x66, 0x66, 0x66, 0x00,
0x00, 0x18, 0x00, 0x38, 0x18, 0x18, 0x3C, 0x00,
0x00, 0x06, 0x00, 0x06, 0x06, 0x06, 0x06, 0x3C,
0x00, 0x60, 0x60, 0x6C, 0x78, 0x6C, 0x66, 0x00,
0x00, 0x38, 0x18, 0x18, 0x18, 0x18, 0x3C, 0x00,
0x00, 0x00, 0x66, 0x7F, 0x7F, 0x6B, 0x63, 0x00,
0x00, 0x00, 0x7C, 0x66, 0x66, 0x66, 0x66, 0x00,
0x00, 0x00, 0x3C, 0x66, 0x66, 0x66, 0x3C, 0x00,
0x00, 0x00, 0x7C, 0x66, 0x66, 0x7C, 0x60, 0x60,
0x00, 0x00, 0x3E, 0x66, 0x66, 0x3E, 0x06, 0x06,
0x00, 0x00, 0x7C, 0x66, 0x60, 0x60, 0x60, 0x00,
0x00, 0x00, 0x3E, 0x60, 0x3C, 0x06, 0x7C, 0x00,
0x00, 0x18, 0x7E, 0x18, 0x18, 0x18, 0x0E, 0x00,
0x00, 0x00, 0x66, 0x66, 0x66, 0x66, 0x3E, 0x00,
0x00, 0x00, 0x66, 0x66, 0x66, 0x3C, 0x18, 0x00,
0x00, 0x00, 0x63, 0x6B, 0x7F, 0x3E, 0x36, 0x00,
0x00, 0x00, 0x66, 0x3C, 0x18, 0x3C, 0x66, 0x00,
0x00, 0x00, 0x66, 0x66, 0x66, 0x3E, 0x0C, 0x78,
0x00, 0x00, 0x7E, 0x0C, 0x18, 0x30, 0x7E, 0x00,

0x14, 0x10, 0x10, 0x40, 0x10, 0x10, 0x14, 0x00, // {
0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18,
0x50, 0x10, 0x10, 0x04, 0x10, 0x10, 0x50, 0x00, // }
0x11, 0x11, 0x44, 0x44, 0x00, 0x00, 0x00, 0x00, // ~
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 // 127 DEL 
};
int main()
{
  int i, string_offset, ret_val;
  int ok;
  uint16 clut[OSD_MAX_LAYERS][OSD_MAX_COLORS][4];
  char * text_ram[OSD_MAX_LAYERS];
  static struct graphics_list * gfx_list[OSD_MAX_LAYERS];
  static struct graphics_list * gfx_instruction;

  static struct yuv8_video_struct yuv8_layer_video[OSD_MAX_LAYERS];
  static struct yuv8_video_struct yuv8_out_video;

  char out_filename[] = "test.yuv";
  char * in_filename[OSD_MAX_LAYERS];
  
  FILE* output_fid     = NULL;
  FILE* input_fid[OSD_MAX_LAYERS];



  // Use default generics for this smoke test
  struct xilinx_ip_v_osd_v6_0_generics generics;


  // Create structure for inputs and input data arrays
  struct xilinx_ip_v_osd_v6_0_inputs inputs;

  // Create structure for outputs and output data arrays
  struct xilinx_ip_v_osd_v6_0_outputs outputs;

  // Create state
  struct xilinx_ip_v_osd_v6_0_state* state;


  generics = xilinx_ip_v_osd_v6_0_get_default_generics();
  generics.C_NUM_LAYERS = 3;
  generics.C_LAYER_TYPE[2] = 1; // Graphics Controller // Declare any arrays in the inputs structure and write pointers to them into the inputs structure
  printf("layer 0 type = %d.\n", generics.C_LAYER_TYPE[0]);
  inputs.num_frames  = 3;
  inputs.color_space = 4; //OSD_YUV;

  inputs.frame_cfg   = (struct frame_cfg_struct *) calloc(1, sizeof(struct frame_cfg_struct));
  inputs.frame_cfg->x_size      = 1280;
  inputs.frame_cfg->y_size      =  720;
  inputs.frame_cfg->bg_color[0] = 0x88;
  inputs.frame_cfg->bg_color[1] = 0x3a;
  inputs.frame_cfg->bg_color[2] = 0xbd;
  inputs.frame_cfg->next        = NULL; // End of Frame Config

  // Setup Layer 0 Configuration
  if (OSD_DEBUG) printf("Setting up Layer 0 Configuration\n");
  inputs.layer_cfg[0] = (struct layer_cfg_struct *) calloc(1, sizeof(struct layer_cfg_struct));
  inputs.layer_cfg[0]->enable      = 1;
  inputs.layer_cfg[0]->g_alpha_en  = 0;
  inputs.layer_cfg[0]->priority    = 2;
  inputs.layer_cfg[0]->alpha       = 0x80;
  inputs.layer_cfg[0]->x_pos       = 0;
  inputs.layer_cfg[0]->y_pos       = 0;
  inputs.layer_cfg[0]->x_size      = 1000;//1280;
  inputs.layer_cfg[0]->y_size      = 100;//720;
  
  inputs.layer_cfg[0]->chan_mode[0] = OSD_SOLID_MODE;
  inputs.layer_cfg[0]->chan_mode[1] = OSD_SOLID_MODE;
  inputs.layer_cfg[0]->chan_mode[2] = OSD_SOLID_MODE;
  inputs.layer_cfg[0]->chan_mode[3] = OSD_HRAMP_MODE;

  inputs.layer_cfg[0]->chan_color[0] = 0xe0;
  inputs.layer_cfg[0]->chan_color[1] = 0x5a;
  inputs.layer_cfg[0]->chan_color[2] = 0xbf;
  inputs.layer_cfg[0]->chan_color[3] = 0x80; // Alpha
  inputs.layer_cfg[0]->next = (struct layer_cfg_struct *) calloc(1, sizeof(struct layer_cfg_struct));

  inputs.layer_cfg[0]->next->enable      = 1;
  inputs.layer_cfg[0]->next->g_alpha_en  = 0;
  inputs.layer_cfg[0]->next->priority    = 2;
  inputs.layer_cfg[0]->next->alpha       = 0x80;
  inputs.layer_cfg[0]->next->x_pos       = 200;
  inputs.layer_cfg[0]->next->y_pos       = 200;
  inputs.layer_cfg[0]->next->x_size      = 1000;//1280;
  inputs.layer_cfg[0]->next->y_size      = 100;//720;
  
  inputs.layer_cfg[0]->next->chan_mode[0] = OSD_SOLID_MODE;
  inputs.layer_cfg[0]->next->chan_mode[1] = OSD_VRAMP_MODE;
  inputs.layer_cfg[0]->next->chan_mode[2] = OSD_SOLID_MODE;
  inputs.layer_cfg[0]->next->chan_mode[3] = OSD_SOLID_MODE;

  inputs.layer_cfg[0]->next->chan_color[0] = 0xe0;
  inputs.layer_cfg[0]->next->chan_color[1] = 0x5a;
  inputs.layer_cfg[0]->next->chan_color[2] = 0xbf;
  inputs.layer_cfg[0]->next->chan_color[3] = 0x80; // Alpha
  inputs.layer_cfg[0]->next->next          = NULL;



  // Setup layer 1 Configuration
  if (OSD_DEBUG) printf("Setting Up Layer 1 Configuration\n");
  inputs.layer_cfg[1] = (struct layer_cfg_struct *) calloc(1, sizeof(struct layer_cfg_struct));
  inputs.layer_cfg[1]->enable      = 1;
  inputs.layer_cfg[1]->g_alpha_en  = 1;
  inputs.layer_cfg[1]->priority    = 1;
  inputs.layer_cfg[1]->alpha       = 0x80;
  inputs.layer_cfg[1]->x_pos       = 600;
  inputs.layer_cfg[1]->y_pos       = 40;
  inputs.layer_cfg[1]->x_size      = 80;
  inputs.layer_cfg[1]->y_size      = 120;
  
  inputs.layer_cfg[1]->chan_mode[0] = OSD_RAND_MODE;
  inputs.layer_cfg[1]->chan_mode[1] = OSD_SOLID_MODE;
  inputs.layer_cfg[1]->chan_mode[2] = OSD_SOLID_MODE;
  inputs.layer_cfg[1]->chan_mode[3] = OSD_SOLID_MODE;

  inputs.layer_cfg[1]->chan_color[0] = 0xa5;
  inputs.layer_cfg[1]->chan_color[1] = 0x44;
  inputs.layer_cfg[1]->chan_color[2] = 0x88;
  inputs.layer_cfg[1]->chan_color[3] = 0x80;
  inputs.layer_cfg[1]->next          = (struct layer_cfg_struct *) calloc(1, sizeof(struct layer_cfg_struct));

  inputs.layer_cfg[1]->next->enable      = 1;
  inputs.layer_cfg[1]->next->g_alpha_en  = 1;
  inputs.layer_cfg[1]->next->priority    = 1;
  inputs.layer_cfg[1]->next->alpha       = 0x80;
  inputs.layer_cfg[1]->next->x_pos       = 620;
  inputs.layer_cfg[1]->next->y_pos       = 70;
  inputs.layer_cfg[1]->next->x_size      = 80;
  inputs.layer_cfg[1]->next->y_size      = 120;
  
  inputs.layer_cfg[1]->next->chan_mode[0] = OSD_VRAMP_MODE;
  inputs.layer_cfg[1]->next->chan_mode[1] = OSD_SOLID_MODE;
  inputs.layer_cfg[1]->next->chan_mode[2] = OSD_SOLID_MODE;
  inputs.layer_cfg[1]->next->chan_mode[3] = OSD_SOLID_MODE;

  inputs.layer_cfg[1]->next->chan_color[0] = 0xa5;
  inputs.layer_cfg[1]->next->chan_color[1] = 0x44;
  inputs.layer_cfg[1]->next->chan_color[2] = 0x88;
  inputs.layer_cfg[1]->next->chan_color[3] = 0x80;
  inputs.layer_cfg[1]->next->next          = NULL;


  // Setup Layer 2 Configuration
  if (OSD_DEBUG) printf("Setting Up Layer 2 Configuration\n");
  inputs.layer_cfg[2] = (struct layer_cfg_struct *) calloc(1, sizeof(struct layer_cfg_struct));
  inputs.layer_cfg[2]->enable      = 1;
  inputs.layer_cfg[2]->g_alpha_en  = 1;
  inputs.layer_cfg[2]->priority    = 0;
  inputs.layer_cfg[2]->alpha       = 0x80;
  inputs.layer_cfg[2]->x_pos       = 100;
  inputs.layer_cfg[2]->y_pos       = 80;
  inputs.layer_cfg[2]->x_size      = 1000;
  inputs.layer_cfg[2]->y_size      = 140;
  
  inputs.layer_cfg[2]->chan_mode[0] = OSD_GRAPHICS_MODE;
  inputs.layer_cfg[2]->next         = NULL;

  // Setup Color Table
  clut[2][0][0] = 0xff;
  clut[2][0][1] = 0x80;
  clut[2][0][2] = 0x80;
  clut[2][0][3] = 0;
  //blue
  clut[2][1][0] = 0x9f;
  clut[2][1][1] = 0xab;
  clut[2][1][2] = 0x55;
  clut[2][1][3] = 0xd0;
  //yelow
  clut[2][2][0] = 0xd2;
  clut[2][2][1] = 0x10;
  clut[2][2][2] = 0x92;
  clut[2][2][3] = 0xd0;
  // Setup Text RAM
  inputs.gfx_cfg[2] = (struct graphics_cfg_struct *) calloc(1, sizeof(struct graphics_cfg_struct));
  generics.C_LAYER_TEXT_NUM_STRINGS[2] = 16; // Set number of strings
  generics.C_LAYER_TEXT_MAX_STRING_LENGTH[2] = 64; //Set max string length 
  // Allocate memory block for text ram
  text_ram[2] = (char *) calloc(generics.C_LAYER_TEXT_NUM_STRINGS[2] * generics.C_LAYER_TEXT_MAX_STRING_LENGTH[2] , sizeof(char));
  inputs.gfx_cfg[2]->text_ram = text_ram[2];
  // Setup Strings
  for(i=0; i<generics.C_LAYER_TEXT_NUM_STRINGS[2]; i++)
  { 
          string_offset = i*generics.C_LAYER_TEXT_MAX_STRING_LENGTH[2];
          //snprintf(&text_ram[2][string_offset], generics.C_LAYER_TEXT_MAX_STRING_LENGTH[2], "Test Text String #%d!", i+1);
          sprintf(&text_ram[2][string_offset], "Test Text String #%d!", i+1);
  }
  // Setup Font RAM
  generics.C_LAYER_FONT_NUM_CHARS[2]    = 128;
  generics.C_LAYER_FONT_WIDTH[2]        = 8;
  generics.C_LAYER_FONT_HEIGHT[2]       = 8;
  generics.C_LAYER_FONT_BPP[2]          = 1;
  generics.C_LAYER_FONT_ASCII_OFFSET[2] = 0;
  inputs.gfx_cfg[2]->font_ram = (int *) &osd_charmap[0];

  // Setup Instruction List
  gfx_list[2] = (struct graphics_list *) calloc(1, sizeof(struct graphics_list));


  gfx_instruction = gfx_list[2];
  gfx_instruction->opcode      = OSD_INS_BOX;
  gfx_instruction->xstart      = 10;
  gfx_instruction->xstop       = 21;
  gfx_instruction->ystart      = 40;
  gfx_instruction->ystop       = 61;
  gfx_instruction->color_index = 1;
  gfx_instruction->object_size = 4;
  gfx_instruction->next        = (struct graphics_list *) calloc(1, sizeof(struct graphics_list));

  gfx_instruction = gfx_instruction->next;
  gfx_instruction->opcode      = OSD_INS_BOX;
  gfx_instruction->xstart      = 40;
  gfx_instruction->xstop       = 60;
  gfx_instruction->ystart      = 55;
  gfx_instruction->ystop       = 77;
  gfx_instruction->color_index = 2;
  gfx_instruction->object_size = 2;
  gfx_instruction->next        = (struct graphics_list *) calloc(1, sizeof(struct graphics_list));
  gfx_instruction = gfx_instruction->next;

  gfx_instruction->opcode      = OSD_INS_TEXT;
  gfx_instruction->xstart      = 0; // Text Ins get X from Start
  gfx_instruction->xstop       = 0; // unused
  gfx_instruction->ystart      = 0; // unused
  gfx_instruction->ystop       = 0; //Text Ins get Y from Stop
  gfx_instruction->color_index = 1;
  gfx_instruction->text_index  = 1;
  gfx_instruction->object_size = 0x40;
  gfx_instruction->next        = (struct graphics_list *) calloc(1, sizeof(struct graphics_list));
  gfx_instruction = gfx_instruction->next;

  gfx_instruction->opcode      = OSD_INS_BOXTEXT;
  gfx_instruction->xstart      = 16; // Text Ins get X from Start
  gfx_instruction->xstop       = 32; // unused
  gfx_instruction->ystart      = 16; // unused
  gfx_instruction->ystop       = 32; //Text Ins get Y from Stop
  gfx_instruction->color_index = 1;
  gfx_instruction->text_index  = 2;
  gfx_instruction->object_size = 4;

  gfx_instruction->next        = NULL;



  // Setup Graphics Controller
  generics.C_LAYER_INS_BOX_EN[2]  = 1;
  generics.C_LAYER_INS_TEXT_EN[2] = 1;
  generics.C_LAYER_CLUT_SIZE[2]   = 256;
  inputs.gfx_cfg[2]->layer_num          = 2;
  inputs.gfx_cfg[2]->clut               = (uint16 *) clut[2];
  inputs.gfx_cfg[2]->graph_instruction  = gfx_list[2];
  inputs.gfx_cfg[2]->next               = NULL;


  // Setup Layer 0 Video Buffer 
  if (OSD_DEBUG) printf("Setting up Layer 0 Buffer\n");
  inputs.video_in[0].frames          = inputs.num_frames;
  inputs.video_in[0].rows            = inputs.layer_cfg[0]->y_size;
  inputs.video_in[0].cols            = inputs.layer_cfg[0]->x_size;
  inputs.video_in[0].mode            = FORMAT_C444_M;
  inputs.video_in[0].bits_per_component = generics.C_DATA_WIDTH;
  inputs.video_in[0].data[0]         = NULL; // Y
  inputs.video_in[0].data[1]         = NULL; // U
  inputs.video_in[0].data[2]         = NULL; // V
  inputs.video_in[0].data[3]         = NULL; // Alpha

  // Setup Layer 1 Video Buffer 
  if (OSD_DEBUG) printf("Setting up Layer 1 Buffer\n");
  inputs.video_in[1].frames          = inputs.num_frames;
  inputs.video_in[1].rows            = inputs.layer_cfg[1]->y_size;
  inputs.video_in[1].cols            = inputs.layer_cfg[1]->x_size;
  inputs.video_in[1].mode            = FORMAT_C444_M;
  inputs.video_in[1].bits_per_component = generics.C_DATA_WIDTH;
  inputs.video_in[1].data[0]         = NULL; // Y
  inputs.video_in[1].data[1]         = NULL; // U
  inputs.video_in[1].data[2]         = NULL; // V
  inputs.video_in[1].data[3]         = NULL; // Alpha

  // Setup Layer 2 Video Buffer 
  if (OSD_DEBUG) printf("Setting up Layer 2 Buffer\n");
  inputs.video_in[2].frames          = inputs.num_frames;
  inputs.video_in[2].rows            = inputs.layer_cfg[2]->y_size;
  inputs.video_in[2].cols            = inputs.layer_cfg[2]->x_size;
  inputs.video_in[2].mode            = FORMAT_C444_M;
  inputs.video_in[2].bits_per_component = generics.C_DATA_WIDTH;
  inputs.video_in[2].data[0]         = NULL; // Y
  inputs.video_in[2].data[1]         = NULL; // U
  inputs.video_in[2].data[2]         = NULL; // V
  inputs.video_in[2].data[3]         = NULL; // Alpha


  // Declare any arrays in the outputs structure and write pointers to them into the outputs structure
  //
  // Setup Output Video Buffer 
  if (OSD_DEBUG) printf("Setting up Output Buffer\n");
  outputs.video_out.frames          = inputs.num_frames;
  outputs.video_out.rows            = inputs.frame_cfg->y_size;
  outputs.video_out.cols            = inputs.frame_cfg->x_size;
  outputs.video_out.mode            = FORMAT_C444;
  outputs.video_out.bits_per_component = generics.C_DATA_WIDTH;
  outputs.video_out.data[0]         = NULL;
  outputs.video_out.data[1]         = NULL;
  outputs.video_out.data[2]         = NULL;



  // Allocate and pre-fill buffers with layer data from file
  for(i=0; i < generics.C_NUM_LAYERS; i++)
  {
    if(inputs.layer_cfg[i]->chan_mode[0] == OSD_PREFILL_MODE)
    {
      //snprintf(in_filename[i], 80, "layer_%d.yuv", i);
      sprintf(in_filename[i], "layer_%d.yuv", i);
      input_fid[i] = NULL;

      if (OSD_DEBUG) printf("Opening Input File '%s'...\n", in_filename[i]);
      if ( (input_fid[i] = fopen(in_filename[i], "rb")) == NULL ) 
      {
        printf( "ERROR: Could not open input yuv file '%s'\n", in_filename[i] ); return(8); 
      }

      //Setup YUV Input buffer for layer i
      yuv8_layer_video[i].frames          = inputs.num_frames;
      yuv8_layer_video[i].rows            = inputs.layer_cfg[i]->y_size;
      yuv8_layer_video[i].cols            = inputs.layer_cfg[i]->x_size;
      yuv8_layer_video[i].chroma_format   = FORMAT_C444;
      yuv8_layer_video[i].bits_per_component = generics.C_DATA_WIDTH;
      yuv8_layer_video[i].y               = NULL;
      yuv8_layer_video[i].u               = NULL;
      yuv8_layer_video[i].v               = NULL;

      // Read YUV file contents into the input frame buffer:
      if (read_yuv8(input_fid[i], &yuv8_layer_video[i])>0) 
      { 
        printf( "ERROR: Could not read input yuv file '%s'\n", in_filename[i] ); 
              return(64); 
      }

      //Copy data to input layer buffer
      copy_yuv8_to_video(&yuv8_layer_video[i], &inputs.video_in[i]);
    }
  }


  state = xilinx_ip_v_osd_v6_0_create_state(generics);
  if (state == NULL) {
    printf("ERROR: could not create state object\n");
    return 1;
  }

  // Create input data frame: constant data
  // Set data in the inputs structure to hard-coded constant values

  // Simulate the core
  printf("Running the C model...\n");
  if (xilinx_ip_v_osd_v6_0_bitacc_simulate(state, inputs, &outputs) != 0) {
    printf("ERROR: simulation did not complete successfully\n");
    return 1;
  } else {
    printf("Simulation completed successfully\n");
  }
  // Check outputs are correct
  //

  //  open new image output file //
  if (OSD_DEBUG) printf("Opening Output File '%s'...\n", out_filename);
  if ( (output_fid = fopen(out_filename, "wb")) == NULL ) 
  {
    printf( "ERROR: Could not open output yuv file '%s'\n", out_filename ); return(8); 
  }
  //Copy output data to yuv structure for writing yuv file out
  copy_video_to_yuv8(&outputs.video_out, &yuv8_out_video);

  printf("Writing Output Data to '%s'...\n", out_filename);
  if (write_yuv8(output_fid, &yuv8_out_video)>0) 
  {

    printf( "ERROR: Could not write to output yuv file '%s'\n", out_filename); 
    ret_val=128; 
  }
  // Compare data in the outputs structure to hard-coded expected outputs
  ok = 1;
  // For any mismatches, report an error and set ok to false

  // That's all of the checks done
  if (ok) {
    printf("Outputs from simulation are correct\n");
  } else {
    printf("Some outputs from simulation are incorrect\n");
  }

  // Destroy the state to free up memory
  xilinx_ip_v_osd_v6_0_destroy_state(state);
  // Free Layer Buffers  
  for(i=0; i < generics.C_NUM_LAYERS; i++)
  {
    if(inputs.layer_cfg[i]->chan_mode[0] == OSD_PREFILL_MODE)
    {
      printf("Freeing Layer YUV Buffer #%d...\n", i);
      free_yuv_frame_buff((struct yuv_video_struct*)&yuv8_layer_video[i]);
    }
    printf("Freeing Layer Video Buffer #%d...\n", i);
    free_video_buff(&inputs.video_in[i]);
  }
  printf("Freeing Output Buffer...\n");
  free_yuv_frame_buff((struct yuv_video_struct*)&yuv8_out_video);
  free_video_buff(&outputs.video_out);
  
  printf("Exiting...\n");
  // Return value indicates if all outputs were correct
  if (ok) {
    return 0;
  } else {
    return 1;
  }

}
