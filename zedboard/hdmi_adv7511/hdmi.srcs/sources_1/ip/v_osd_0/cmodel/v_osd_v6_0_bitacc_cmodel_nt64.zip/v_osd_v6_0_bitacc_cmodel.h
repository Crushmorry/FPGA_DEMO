//-----------------------------------------------------------------------------
//   ____  ____
//  /   /\/   /
// /___/  \  /   Vendor: Xilinx
// \   \   \/    Version: 5.01a
//  \   \        Filename: $RCSfile: v_osd_v6_0_bitacc_cmodel.h,v $
//  /   /        Date Last Modified: $Date: 2010-10-29 21:52:57 -0600 (Fri, 29 Oct 2010) $
// /___/   /\    Date Created: 2009
// \   \  /  \
//  \___\/\___\
//
// Device  : All
// Library : v_osd_v6_0
// Purpose : Header file for bit accurate C model
//-----------------------------------------------------------------------------
//  (c) Copyright 2011-2012 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES. 
//
//  All rights reserved.
//-----------------------------------------------------------------------------

#ifndef v_osd_v6_0_bitacc_cmodel_h
#define v_osd_v6_0_bitacc_cmodel_h

#ifdef NT
#define DLLIMPORT __declspec(dllimport)
#else
#define DLLIMPORT
#endif

#ifndef Ip_xilinx_ip_v_osd_v6_0_DLL
#define Ip_xilinx_ip_v_osd_v6_0_DLL DLLIMPORT
#endif
#include "rgb_utils.h"
#include "video_utils.h"

#ifdef  __cplusplus
extern "C" {
#endif

#include "rgb_utils.h"
////////////////////////////////////////////////////////////////////////////
// Defines
////////////////////////////////////////////////////////////////////////////
#define OSD_DEBUG 1
#define OSD_MAX_LAYERS 8
#define OSD_MAX_COLORS 256
//Max number of lines in the config files
#define OSD_MAX_CFGFILE 40000

#define OSD_PREFILL_MODE 0
#define OSD_GRAPHICS_MODE     1
#define OSD_CHECKER_MODE 2
#define OSD_RAND_MODE    3
#define OSD_SOLID_MODE   4
#define OSD_HRAMP_MODE   5 
#define OSD_VRAMP_MODE   6
#define OSD_TEMPR_MODE   7

#define OSD_YUV 0
#define OSD_RGB 1

#define OSD_INS_BOX 0x0a
#define OSD_INS_TEXT 0x0e 
#define OSD_INS_BOXTEXT 0x0f 
////////////////////////////////////////////////////////////////////////////
// Structure Definitions
////////////////////////////////////////////////////////////////////////////
struct osd_cfg_struct
{
  int data_width;
  int num_layers;
  int num_channels;
  int color_space; //Not from Generics
  int num_frames; // Not From Generics

  int layer_box_enable[OSD_MAX_LAYERS];
  int layer_text_enable[OSD_MAX_LAYERS];
  int layer_clut_size[OSD_MAX_LAYERS];
  int layer_text_num_strings[OSD_MAX_LAYERS];
  int layer_text_max_string_len[OSD_MAX_LAYERS];
  int layer_font_num_chars[OSD_MAX_LAYERS];
  int layer_font_width[OSD_MAX_LAYERS];
  int layer_font_height[OSD_MAX_LAYERS];
  int layer_font_bpp[OSD_MAX_LAYERS];
  int layer_font_ascii_offset[OSD_MAX_LAYERS];

};

struct frame_cfg_struct
{
  int y_size;
  int x_size;
  int bg_color[3];

  struct frame_cfg_struct * next; // For Changing parameters each Frame
};

struct layer_cfg_struct
{
  int enable;
  int g_alpha_en;
  int priority;
  int alpha;
  int x_pos;
  int y_pos;
  int x_size;
  int y_size;
  
  int chan_mode[4];
  int chan_color[4];

  struct layer_cfg_struct * next; // For Changing parameters each Frame
};

struct graphics_list
{
  int opcode;
  int xstart;
  int xstop;
  int ystart;
  int ystop;
  int color_index;
  int text_index;
  int object_size;
 
  struct graphics_list * next;

};

struct graphics_cfg_struct
{
  int layer_num;

  uint16 * clut; // Color Table
  char * text_ram; // Text Ram
  int * font_ram; // Font Ram 

  struct graphics_list * graph_instruction;

  struct graphics_cfg_struct * next; // For Changing parameters each Frame
};

extern const int osd_charmap[1024];


struct xilinx_ip_v_osd_v6_0_generics
{
  /**
   * v_osd_v6_0 Core Generics
   *
   * These are the only generics that influence the operation of this bit-accurate model.
   */
  int C_DATA_WIDTH;               //@- Input width: 8 bits
  int C_NUM_LAYERS;               //@- Number of Layers: 1-8
  //int C_NUM_DATA_CHANNELS;      //@- Number of data channels: 2,3
  //int C_OUTPUT_MODE;            //@- Output Mode 0=VFBC,1=XSVI

  int C_LAYER_TYPE[OSD_MAX_LAYERS]; //@- Layer Type: 1=graphics controller,2=VFBC
  int C_LAYER_INS_BOX_EN[OSD_MAX_LAYERS];  //@- Box Instruction Enables
  int C_LAYER_INS_TEXT_EN[OSD_MAX_LAYERS]; //@- Text Instruction Enables
  int C_LAYER_CLUT_SIZE[OSD_MAX_LAYERS];   //@- Color Lut size: 16 or 256
  int C_LAYER_TEXT_NUM_STRINGS[OSD_MAX_LAYERS];   //@- Number of Strings
  int C_LAYER_TEXT_MAX_STRING_LENGTH[OSD_MAX_LAYERS]; //@- Max String Length
  int C_LAYER_FONT_NUM_CHARS[OSD_MAX_LAYERS];    //@- Number of Characters
  int C_LAYER_FONT_WIDTH[OSD_MAX_LAYERS];  //@- Font Width in pixels
  int C_LAYER_FONT_HEIGHT[OSD_MAX_LAYERS]; //@- Font Height in lines
  int C_LAYER_FONT_BPP[OSD_MAX_LAYERS];    //@- Font bits per pixel
  int C_LAYER_FONT_ASCII_OFFSET[OSD_MAX_LAYERS]; //@- ASCII value of first character

}; // xilinx_ip_v_osd_v6_0_generics


/**
 * Get list of default generics.
 *
 * @returns xilinx_ip_v_osd_v6_0_generics  Default generics.
 */
Ip_xilinx_ip_v_osd_v6_0_DLL
struct xilinx_ip_v_osd_v6_0_generics
xilinx_ip_v_osd_v6_0_get_default_generics();


/**
 * Structure containing the state of this C-Model.
 *
 * NOTE:  State may persist between simulations.
 */
struct xilinx_ip_v_osd_v6_0_state;


/**
 * Create a new state structure for this C-Model.
 *
 * IMPORTANT: Client is responsible for calling xilinx_ip_v_osd_v6_0_destroy_state()
 *            to free state memory.
 *
 * @param generics    Generics to be used to configure C-Model state.
 *
 * @returns xilinx_ip_v_osd_v6_0_state*  Pointer to the internal state.
 */
Ip_xilinx_ip_v_osd_v6_0_DLL
struct xilinx_ip_v_osd_v6_0_state*
xilinx_ip_v_osd_v6_0_create_state(struct xilinx_ip_v_osd_v6_0_generics generics);


/**
 * Destroy a state structure.
 *
 * @param state    State structure to be destroyed (freed in memory).
 */
Ip_xilinx_ip_v_osd_v6_0_DLL
void xilinx_ip_v_osd_v6_0_destroy_state(struct xilinx_ip_v_osd_v6_0_state* state);


/**
 * Structure to capture all inputs to the v_osd_v6_0 C-Model.
 *
 * @param scalar            A scalar input to the model. Describe the purpose of this
 *                          input here and state its permitted range. List any
 *                          restrictions due to generics or other inputs.
 * @param array             An array input to the model .Describe the purpose of this
 *                          input here and state its permitted / required number of
 *                          array elements and permitted range of element values. List
 *                          any restrictions due to generics or other inputs.
 * @param array_size        Size of array input. An array_size input must accompany
 *                          every array input. State its permitted / required value.
 // Describe your C model inputs here using the above format
 */
struct xilinx_ip_v_osd_v6_0_inputs
{
  struct  video_struct video_in[OSD_MAX_LAYERS]; 

  struct frame_cfg_struct * frame_cfg;
  struct layer_cfg_struct *layer_cfg[OSD_MAX_LAYERS];
  struct graphics_cfg_struct * gfx_cfg[OSD_MAX_LAYERS];
 
  int     num_frames;
  int     color_space;

  // Enter your C model inputs here using the above format

}; // end xilinx_ip_v_osd_v6_0_inputs


/**
 * Structure to capture all outputs from the v_osd_v6_0 C-Model.
 *
 * Before using this structure the user is responsible for allocating enough memory
 * for each output array, and specifying the number of array elements allocated in
 * the _size parameters. If the _size values are too small, the model will fail with
 * an error. It is OK to allocate more memory than is required and specify a larger
 * number of array elements than required in the _size parameters. The model will set
 * the _size parameters to indicate the number of array elements that contain valid
 * output data.
 *
 * @param scalar         A scalar output. Describe it here.
 * @param array          An array output. Describe it here.
 * @param array_size     Size of array output. State its required minimum value.
 // Describe your C model outputs here using the above format
 */
struct xilinx_ip_v_osd_v6_0_outputs
{
  struct  video_struct video_out;

  // Enter your C model outputs here using the above format

}; // xilinx_ip_v_osd_v6_0_outputs


/**
 * Simulate this bit-accurate C-Model.
 *
 * @param     state      Internal state of this C-Model. State
 *                       may span multiple simulations.
 * @param     inputs     Inputs to this C-Model.
 * @param     outputs    Outputs from this C-Model.
 *
 * @returns   Exit code   Zero for SUCCESS, Non-zero otherwise.
 */
Ip_xilinx_ip_v_osd_v6_0_DLL
int xilinx_ip_v_osd_v6_0_bitacc_simulate
(
 struct xilinx_ip_v_osd_v6_0_state*   state,
 struct xilinx_ip_v_osd_v6_0_inputs   inputs,
 struct xilinx_ip_v_osd_v6_0_outputs* outputs
 );


Ip_xilinx_ip_v_osd_v6_0_DLL int osd_parse_args
(
 int argc, 
 char* argv[], 
 struct xilinx_ip_v_osd_v6_0_generics * generics_ptr, 
 struct xilinx_ip_v_osd_v6_0_inputs * inputs_ptr,
 char *osd_files[],
 int *mode
 );
#ifdef  __cplusplus
}
#endif


#endif // v_osd_v6_0_bitacc_cmodel_h
